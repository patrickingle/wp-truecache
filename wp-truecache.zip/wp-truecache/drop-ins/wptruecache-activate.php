<?php
/*
	DO NOT DELETE THIS FILE OR WPTRUECACHE-HA Plugin will not function evenn though active.
	
	This is a placeholder file and tells the WPTRUECACHE plug in during wordpress bootup that the plugin is activated
	
*/
?>