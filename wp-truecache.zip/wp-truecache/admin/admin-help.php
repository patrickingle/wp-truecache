<?php
include 'docs/index.htm';
?>