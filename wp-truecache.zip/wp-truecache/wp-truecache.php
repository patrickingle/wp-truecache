<?php
/*
Plugin Name: WP True Cache
Plugin URI: http://github.com/patrickingle/wp-truecache
Description: A plugin that properly enables Wordpress in a high available, cluster environment using Memcache with File caching failover
Version: 2.0.6
Author: Patrick Ingle
Author URI: http://github.com/patrickingle
License: GPL2
*/

//custom updates/upgrades
$this_file = __FILE__;
$update_check = WPTRUECACHE_UPDATE_URL;
require_once(dirname(__FILE__).'/gill-updates.php');

function check_perms($path,$perm) {
	clearstatcache();
	$configmod = substr(sprintf('%o',fileperms($path)),-4);
	$trcss = (($configmod != $perm) ? FALSE : TRUE);
	return $trcss;
}

function wptruecache_error($messages) {
	foreach ($messages as $message)
	 	_e($message);
	exit;
}

function wptruecache_check_for_conflicts() {
	$results = array();
	$cache_path = WP_CONTENT_DIR . '/cache';

	if (defined('WP_TRUECACHE_CHECK_PERMISSIONS')) {
		if (check_perms(WP_CONTENT_DIR,'0777') == FALSE) {
			$results[] = '<br>'.WP_CONTENT_DIR.' is NOT writable! change permissions to 777<br>';
		}
		
		if (file_exists($cache_path)) {
			if (check_perms($cache_path,'0777')) {
				$results[] = '<br>' . $cache_path . ' is NOT writable! change permissions to 777<br>';
			}
		} else {
			if (!@mkdir($cache_path)) {
				$error = error_get_last();
				$results[] = $error['message'];
			}
		}
	} else {
		if (!file_exists($cache_path)) {
			if (!@mkdir($cache_path)) {
				$error = error_get_last();
				$results[] = $error['message'];
			}
		}
	}
	
	if (file_exists(WP_CONTENT_DIR.'/object-cache.php')) {
		$results[] = 'object-cache.php exists, possible conflict';	
	}
	
	if (file_exists(WP_CONTENT_DIR.'/advanced-cache.php')) {
		$results[] = 'advanced-cache.php exists, possible conflict';
	}
	
	return $results;
}

function wptruecache_check_for_dependencies() {
	$results = array();
	
	if (!extension_loaded('memcache')) {
		if (!@dl('memcache.so')) {
			$results[] = 'memcache not loaded'; 
		}
	}
	
	$backup_path = WP_PLUGIN_DIR . '/wp-truecache/backup';
	if (!file_exists($backup_path)) {
		if (!@mkdir($backup_path)) {
			$error = error_get_last();
			$results[] = $error['message'];
		}
	}
		
	return $results;	
}

function wptruecache_check_for_existence() {
	$results = array();
	
	if (defined('WPTRUECACHE_ADVANCED_CACHE_INSTALLED')) {
		$results[] = '<br>WP-TrueCache Advanced Cache is installed<br>';
	}

	if (!defined('WP_MEMCACHE_FULL_SERVER_LIST')) {
		if (!defined('WP_MEMCACHE_SERVERS')) {
			$results[] = '<br>Neither WP_MEMCACHE_SERVERS nor WP_MEMCACHE_FULL_SERVER_LIST is DEFINED<br>';
		}
		
		if (!defined('WP_MEMCACHE_PORT')) {
			$results[] = '<br>WP_MEMCACHE_PORT is NOT DEFINED<br>';
		}
	}
	

	if (!defined('WP_CACHE')) {
		$results[] = '<br>WP_CACHE is not defined!<br>';
	} else {
		if (WP_CACHE == FALSE) {
			$results[] = '<br>WP_CACHE is defined as FALSE and should be defined as TRUE!<br>';
		}
	}
	
	if (!defined('WPTRUECACHE_VERSION')) {
		$results[] = '<br>WPTRUECACHE_VERSION is not defined. Please add include(ABSPATH."wp-content/plugins/wp-truecache/config.php"); to the top of wp-config.php file<br>';
	}

//	if (!is_multisite()) {
//		$results[] = 'Multisite is NOT enabled';
//	}
	
	return $results;
}

function wptruecache_copy_files() {
	$results = array();
	
	if (@copy(WP_PLUGIN_DIR.'/wp-truecache/drop-ins/advanced-cache.php',WP_CONTENT_DIR.'/advanced-cache.php') == FALSE ) {
		$error = error_get_last();
		$results[] = $error['message'];
	}

	if (@copy(WP_PLUGIN_DIR.'/wp-truecache/drop-ins/wptruecache-activate.php',WP_CONTENT_DIR.'/wptruecache-activate.php') == FALSE ) {
		$error = error_get_last();
		$results[] = $error['message'];
	}

	return $results;
}

function wptruecache_backup_files($filename) {
	$results = array();

	if (file_exists($filename) ) {
		$basename = basename($filename);
		$timestamp = date('Ymd') . '_' . microtime();
		$backfilename = WP_PLUGIN_DIR . '/wp-truecache/backup/backup_'. $basename .'_' . $timestamp;
		if (!@copy($filename,$backfilename)) {
			$error = error_get_last();
			$results[] = $error['message'];		
		}		
	} else {
		$results[] = 'Cannot file the file: ' . $basename . '<br>';
	}
	
	return $results;
}

function wptruecache_backup_wpconfig() {
	$results = array();
	
	if (file_exists(ABSPATH.'wp-config.php')) {
		$results = wptruecache_backup_files(ABSPATH.'wp-config.php');		
	} else if (file_exists(ABSPATH.'../wp-config.php')) {
		$results = wptruecache_backup_files(ABSPATH.'../wp-config.php');
	} else {
		$results[] = 'Cannot find the wp-config.php file? <br>';
	}
	
	return $results;
}

function wptruecache_remove_files() {
	$results = array();
	
	if (file_exists(WP_CONTENT_DIR.'/advanced-cache.php')) {
		if (@unlink(WP_CONTENT_DIR.'/advanced-cache.php') == FALSE) {
			$error = error_get_last();
			$results[] = $error['message'];
		}
	}
	
	if (file_exists(WP_CONTENT_DIR.'/wptruecache-activate.php')) {
		if (@unlink(WP_CONTENT_DIR.'/wptruecache-activate.php') == FALSE) {
			$error = error_get_last();
			$results[] = $error['message'];
		}
	}
	
	return $results;
}

function wptruecache_activate() {
	// Check to see if object-cache and advanced-cache exists in the wp-content path, if these files exist
	// then we cannot activate this plugin as they will conflict.
	$results = wptruecache_check_for_conflicts();
	if (count($results) > 0) wptruecache_error($results);
	
	$results = wptruecache_check_for_dependencies();
	if (count($results) > 0) wptruecache_error($results);
	
	$results = wptruecache_check_for_existence();
	if (count($results) > 0) wptruecache_error($results);

	$results = wptruecache_backup_wpconfig();
	if (count($results)) wptruecache_error($results);
		
	// Ok, to copy from ./drop-ins path to wp-content
	$results = wptruecache_copy_files();
	if (count($results) > 0) {
		wptruecache_remove_files();
		wptruecache_error($results);
	}
	
	set_error_handler('wptruecache_error_handler',E_ALL|E_STRICT);

	$current_user = wp_get_current_user();
	$message = 'NOTICE: WP-TrueCache plugin has been ACTIVATED by user '.$current_user->user_login.' on '.date('D, d M Y H:i:s');
	error_log($message);
	
	if (defined('WP_TRUECACHE_EMAILNOTIFY')) wp_main(WP_TRUECACHE_EMAILNOTIFY,'WP-TrueCache Notification',$message);
}

function wptruecache_deactivate() {
	$results = array();
	
	if (defined('WPTRUECACHE_ADVANCED_CACHE_INSTALLED')) {
		$results = wptruecache_remove_files();
		if (count($results) > 0) {
			$results[] = '<br>WP-TrueCache Advanced Cache is installed. Must delete the advanced-cache.php file before deactivating the plugin. <a href="javascript:history.back(-1);">back</a><br>';			
		}
	}
	
	if (count($results) > 0) {
		wptruecache_error($results);
	} else {
		remove_submenu_page('wp-truecache/admin/admin-index.php','filecache');
		remove_submenu_page('wp-truecache/admin/admin-index.php','memcache');
		remove_menu_page('wp-truecache/admin/admin-index.php');
	}		
	
	restore_error_handler(); 
	
	$current_user = wp_get_current_user();
	$message = 'NOTICE: WP-TrueCache plugin has been DEACTIVATED by user '.$current_user->user_login.' on '.date('D, d M Y H:i:s');
	error_log($message);

	if (defined('WP_TRUECACHE_EMAILNOTIFY')) wp_main(WP_TRUECACHE_EMAILNOTIFY,'WP-TrueCache Notification',$message);
}

function wptruecache_uninstall() {
	
}

function wptruecache_error_handler($errno, $errstr, $errfile, $errline) {
	$message = '';
	
	if (!(error_reporting() & $errno)) {
        // This error code is not included in error_reporting
        return;
    }

    switch ($errno) {
    case E_USER_ERROR:
        $message = "<b>ERROR</b> [$errno] $errstr<br />\n";
        $message .= "  Fatal error on line $errline in file $errfile";
        $message .= ", PHP " . PHP_VERSION . " (" . PHP_OS . ")<br />\n";
        $message .= "Aborting...<br />\n";
        exit(1);
        break;

    case E_USER_WARNING:
        $message = "<b>WARNING</b> [$errno] $errstr<br />\n";
        break;

    case E_USER_NOTICE:
        $message = "<b>NOTICE</b> [$errno] $errstr<br />\n";
        break;

    default:
        $message = "Unknown error type: [$errno] $errstr<br />\n";
        break;
    }
	
	error_log($message);

	if (wp_mail(WP_TRUECACHE_EMAIL1,'WP-TrueCache: Error Occurred',$message) == FALSE ) {
		error_log($exception->getMessage());
	}

    /* Don't execute PHP internal error handler */
    return true;
}

register_activation_hook( __FILE__, 'wptruecache_activate' );
register_deactivation_hook( __FILE__, 'wptruecache_deactivate' );
//register_uninstall_hook( __FILE__, 'wptruecache_uninstall' );

require(dirname(__FILE__).'/admin.php');


?>
